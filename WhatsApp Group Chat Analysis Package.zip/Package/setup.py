from setuptools import setup, find_packages
import codecs
import os
from pathlib import Path

long_description = 'As the name suggest, it is Whatsapp Group Chat analysis package. It will basically help the programmers to generate' \
                   ' visual insights extracted from the whatsapp group chat. You need to do nothing, just ' \
                   'export the group chat and use this package to generate or create beautiful different-different charts.' \
                   ' Here you do not have to worry about anything, internally it will do everything for you. It will perform ETL(Extract-Transform-Load) and finally generate insights ' \
                   'in the form of visuals. There are approx. more than 15 methods are available which will help you to generate insights, even you can download each and every insight.' \
                   '' \
                   ' For More Details visit : https://github.com/ronylpatil/WhatsApp-Group-Chat-Analyzer-Package'

VERSION = '0.0.1'
DESCRIPTION = 'This library or package will extract various insights from whatsapp chat and convert that insights into beautiful interactive visual\'s in just 2-3 lines of code.'

# Setting up
setup(
    name="WhatsApp-Group-Chat-Analysis",
    version=VERSION,
    author="ronil08",
    author_email="ronyy0080@gmail.com",
    description=DESCRIPTION,
    long_description_content_type="text/markdown",
    long_description= long_description,
    licens='MIT',
    packages=find_packages(),
    install_requires=['plotly', 'nltk', 'numpy', 'emoji', 'wordcloud', 'matplotlib', 'pandas'],
    keywords=['whatsapp analyzer', 'whatsapp lib', 'whatsapp analysis', 'whatsapp python', 'chat', 'whatsapp group chat analysis', 'whatsapp library', 'ronil patil', 'ronil08'],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Operating System :: Unix",
        "Operating System :: MacOS :: MacOS X",
        "Operating System :: Microsoft :: Windows",
    ]
)